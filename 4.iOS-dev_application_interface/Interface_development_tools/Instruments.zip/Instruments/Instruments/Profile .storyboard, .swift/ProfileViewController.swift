//
//  ProfileViewController.swift
//  Instruments
//
//  Created by Yan Sakhnevich on 11.10.2021.
//

import UIKit

class ProfileViewController: UIViewController {
    
    private var profileView: UIView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let profileViewName = String(describing: ProfileView.self)
        
        if let profileView = Bundle.main.loadNibNamed(profileViewName, owner: nil, options: nil)?.first as? ProfileView {
            profileView.frame = CGRect(x: 15, y: 100, width: view.bounds.width - 30, height: 450)
            self.profileView = profileView
            view.addSubview(profileView)
            
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        if UIDevice.current.orientation.isLandscape {
            profileView?.frame = CGRect(x: 40, y: 30, width: view.bounds.width - 80, height: 300)
            
        }
    }
}
