//
//  ViewController.swift
//  Instruments
//
//  Created by Yan Sakhnevich on 11.10.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

