//
//  ProfileView.swift
//  Instruments
//
//  Created by Yan Sakhnevich on 11.10.2021.
//

import UIKit

class ProfileView: UIView {

    @IBOutlet weak var userAvatar: UIImageView!
    
    @IBOutlet weak var userName: UILabel!
    
    
    @IBOutlet weak var userBirthday: UILabel!
    
    
    @IBOutlet weak var userCity: UILabel!
    
    
    @IBOutlet weak var userAbout: UITextView!
    
    

}
